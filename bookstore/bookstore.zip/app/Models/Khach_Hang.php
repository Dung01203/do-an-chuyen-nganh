<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Khach_Hang extends Model
{
    protected $table = 'khach_hang';
    protected $fillable = [
        'id', 'ho_khach_hang', 'ten_khach_hang', 'email', 'password', 'dia_chi', 'sdt', 'thanh_vien', 'created_at', 'updated_at'
    ];
   
}