<h3>Đơn đặt hàng</h3>
<table class="table" width="100%">
    <tr>
        <td><b>Số hóa đơn</b></td>
        <td><?php echo e($DonDatHang[0]->id); ?></td>
        <td><b>Ngày hóa đơn</b></td>
        <td><?php echo e($DonDatHang[0]->ngay_dat); ?></td>
    </tr>
    <tr>
        <td><b>Khách hàng</b></td>
        <td><?php echo e($DonDatHang[0]->ho_khach_hang); ?>&nbsp;<?php echo e($DonDatHang[0]->ten_khach_hang); ?></td>
        <td><b>Điện thoại</b></td>
        <td><?php echo e($DonDatHang[0]->sdt); ?></td>
        <td><b>Email</b></td>
        <td><?php echo e($DonDatHang[0]->email); ?></td>
    </tr>
    <tr>
        <td><b>Địa chỉ</b></td>
        <td colspan="5"><?php echo e($DonDatHang[0]->dia_chi); ?></td>
    </tr>
</table>
<table class="table" width="100%">
    <thead>
        <tr style="background-color: #02acea">
            <td>#</td>
            <td>Mã SP</td>
            <td>Tên SP</td>
            <td>Số lượng</td>
            <td>Đơn giá</td>
            <td>Thành tiền</td>
        </tr>
    </thead>

    <tbody>
        <?php $i = 1 ?>
        <?php $__currentLoopData = $DonDatHang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo $i; ?></th>
            <td><?php echo e($dh->MaSP); ?></td>
            <td><?php echo e($dh->ten_sach); ?></td>
            <td><?php echo e($dh->so_luong); ?></td>
            <td><?php echo e(number_format($dh->don_gia)); ?></td>
            <td><?php echo e(number_format($dh->so_luong *$dh->don_gia)); ?></td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr style="background-color: #cacaca">
            <td colspan="5">Số Lượng </td>
            	<td><?php echo e(Cart::count()); ?></td>
        </tr>
        <tr style="background-color: #02acea">
            <td colspan="5">Tổng tiền</td>
            <td><?php echo e(number_format($DonDatHang[0]->tong_tien)); ?></td>
        </tr>

    </tfoot>
</table><?php /**PATH C:\wamp64\www\bookstore\resources\views/emails/donhang.blade.php ENDPATH**/ ?>