
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>
<div class="breadcrumb">
    <div class="container">
        <a class="breadcrumb-item" href="/">Home</a>
        <span class="breadcrumb-item active">Register</span>
    </div>
</div>
<section class="static about-sec">
    <div class="container">
        <h1 style="text-align: center;">Xác Nhận Thông Tin </h1>
        <div class="form">
            <form method="POST" action="<?php echo e(url('khach-hang/thong-tin-khach-hang')); ?>" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-12">
                            <label for="ho_kh"> Họ Khách Hàng:</label>
                            <input type="text" value="<?php echo e($khach_hang->ho_khach_hang); ?>" name="ho_kh" placeholder="Họ Người Đặt" required>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <div class="col-md-12">
                        <label for="ten_kh">Tên Khách Hàng:</label>
                            <input type="text" name="ten_kh" value="<?php echo e($khach_hang->ten_khach_hang); ?>" placeholder=" Tên Người Đặt" required>
                        </div>
                        <div class="col-md-12">
                        <label for="dia_chi">Địa chỉ:</label>
                            <input type="text" name="dia_chi" value="<?php echo e($khach_hang->dia_chi); ?>" placeholder="Địa Chỉ" required>
                        </div>
                        <div class="col-md-12">
                        <label for="sdt">Số Điện Thoại:</label>
                            <input type="text" name="sdt" value="<?php echo e($khach_hang->sdt); ?>" placeholder="Điện Thoại Người Nhận" required>
                        </div>
                        <div class="col-lg-8 col-md-12">
                                  <button  name="submit" class="btn black">Đặt Hàng</button>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/khach_hang/thong_tin_don_hang.blade.php ENDPATH**/ ?>