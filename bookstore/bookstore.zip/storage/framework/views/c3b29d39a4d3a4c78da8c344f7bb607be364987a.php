
<?php $__env->startSection('title', 'Chi-tiet'); ?>
<?php $__env->startSection('content'); ?>
<section class="recomended-sec">
    <div class="container">
        <div class="title">
            <h2>Danh Mục Tổng Hợp</h2>
            <hr>
        </div>
        <div class="row">
            <?php $__currentLoopData = $loaisach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <h3><?php echo e($ls->ten_loai_sach); ?></h3>
                    <div class="hover">
                        <a href="<?php echo e(url('sach/thu-vien-sach')); ?>/<?php echo e($ls->ten_url); ?>-<?php echo e($ls->id); ?>" >
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
                <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/san_pham/the_loai.blade.php ENDPATH**/ ?>