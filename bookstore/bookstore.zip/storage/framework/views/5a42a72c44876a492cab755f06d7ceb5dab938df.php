
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>
<?php if(count($errors)>0): ?>
<div class="alert alert-success">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?>
<?php if(session('alert')): ?>

<div class="alert alert-danger">
    <?php echo e(session('alert')); ?>

</div>
<?php endif; ?>
<div class="breadcrumb">
    <div class="container">
        <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">Home</a>
        <span class="breadcrumb-item active">Register</span>
    </div>
</div>
<section class="static about-sec">
    <div class="container">
        <h1>Đăng Ký </h1>
        <div class="form">
            <form method="POST" action="<?php echo e(url('khach-hang/dang-ky')); ?>" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-12">
                            <input type="text" value="<?php echo e(old('ho_kh')); ?>" name="ho_kh" placeholder="Họ" required>
                            <span class="required-star">*</span>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <div class="col-md-12">
                            <input type="text" name="ten_kh" value="<?php echo e(old('ten_kh')); ?>" placeholder=" Tên" required>
                            <span class="required-star">*</span>
                        </div>
                        <div class="col-md-12">
                            <input type="email" value="<?php echo e(old('email')); ?>" name="email" placeholder="Email" required>
                            <span class="required-star">*</span>
                        </div>
                        <div class="col-md-12">
                            <input type="password"  id="password" name="password" placeholder=" Password" required>
                            <span class="required-star">*</span>
                        </div>
                        <div class="col-md-12">
                            <span id='message'></span>
                            <input type="password" id="confirm_password" name="confirm_password" placeholder="confirm_password" required>
                            <span class="required-star">*</span>
                        </div>
                        <div class="col-md-12">
                            <input type="text" name="dia_chi" value="<?php echo e(old('dia_chi')); ?>" placeholder="Địa Chỉ" required>
                            <span class="required-star">*</span>
                        </div>
                        <div class="col-md-12">
                            <input type="text" name="sdt" value="<?php echo e(old('sdt')); ?>" placeholder="Điện Thoại" required>
                            <span class="required-star">*</span>
                        </div>
                        <div class="col-lg-8 col-md-12">
                            <button name="submit" class="btn black">Đăng Ký</button>
                            <h5>not Registered? <a href="<?php echo e(url('khach-hang/dang-nhap')); ?>">Login here</a></h5>
                        </div>
                    </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$('#password, #confirm_password').on('keyup', function () {
  if ($('#password').val() == $('#confirm_password').val()) {
    $('#message').html('Trùng Khớp').css('color', 'green');
  } else 
    $('#message').html('Không Trùng').css('color', 'red');
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/khach_hang/register.blade.php ENDPATH**/ ?>