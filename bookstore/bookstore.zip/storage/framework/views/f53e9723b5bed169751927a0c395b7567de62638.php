
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <?php if(count($errors)>0): ?>
    <div class="alert alert-success">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php endif; ?>
    <?php if(session('alert')): ?>
    
    <div class="alert alert-danger">
      <?php echo e(session('alert')); ?>

    </div>
    <?php endif; ?>
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
      <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Danh Sách Khách Hàng </h4>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>
                      STT
                    </th>
                    <th>
                      ID Khách Hàng 
                    </th>
                    <th>
                      Ngày đặt 
                    </th>
                    <th>
                      Tổng tiền 
                    </th>
                    
                    
                  </tr>
                </thead>
                <tbody>

                  <?php $__currentLoopData = $don_hang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $H_Don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <?php echo e($H_Don->id); ?>

                    </td>
                    <td>
                      <?php echo e($H_Don->id_khach_hang); ?>

                    </td>
                    <td>
                      <?php echo e($H_Don->ngay_dat); ?>

                    </td>
                    <td>
                      <?php echo e($H_Don->tong_tien); ?>

                    </td>
                    
                    
                    
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-12">
            <nav aria-label="Page navigation example">
              <ul class="pagination justify-content-center">
                <?php echo e($don_hang->links()); ?>

              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/admin/ds-don-hang.blade.php ENDPATH**/ ?>