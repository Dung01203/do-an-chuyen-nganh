
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>

<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
    <div class="col-md-12">
    <?php if(count($errors)>0): ?>
    <div class="alert alert-success">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php endif; ?>
    <?php if(session('alert')): ?>
    
    <div class="alert alert-danger">
      <?php echo e(session('alert')); ?>

    </div>
    <?php endif; ?>
  </div>

      <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Thêm Nhà Xuất Bản </h4>
            <form class="forms-sample" method="POST" action="<?php echo e(URL('admin/them-nxb')); ?>" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <div class="form-group">
                <label>Tên Nhà Xuất Bản :</label>
                <input type="text" class="form-control" name="ten_nha_xuat_ban" id="ten_nha_xuat_ban" value="<?php echo e(old('ten_nha_xuat_ban')); ?>" placeholder="Nhập tên Nhà Xuất Bản ">
              </div>
              <div class="form-group">
                <label>Địa chỉ  :</label>
                <input type="text" class="form-control" name="dia_chi" id="dia_chi" value="<?php echo e(old('dia_chi')); ?>" placeholder="Nhập tên Nhà Xuất Bản ">
              </div>
              <div class="form-group">
                <label>Số điện thoại:</label>
                <input type="text" class="form-control" name="dien_thoai" value="<?php echo e(old('dien_thoai')); ?>">
              </div>
              <div class="form-group">
                <label>Email:</label>
                <input type="email" class="form- control" name="email" value="<?php echo e(old('email')); ?>">
              </div>
              
              <button type="submit" class="btn btn-primary mr-2">Thêm </button>

            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/admin/them-nxb.blade.php ENDPATH**/ ?>