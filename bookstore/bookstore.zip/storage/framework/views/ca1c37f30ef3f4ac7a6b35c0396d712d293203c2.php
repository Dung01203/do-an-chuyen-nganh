
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/admin/index.blade.php ENDPATH**/ ?>