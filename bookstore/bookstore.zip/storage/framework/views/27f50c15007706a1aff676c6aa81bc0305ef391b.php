
<?php $__env->startSection('title','Danh sach loai san pham'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
        <?php if(Cart::count() === 0): ?>
					    <h3 style="text-align: center;">Giỏ hàng rỗng, 
					    	<a href="<?php echo e(url('/')); ?>">Tiếp tục mua hàng</a>
					    </h3>
					<?php else: ?>
					    <table class="table" style="margin-top: 15px">
						  <thead class="bg-info">
						    <tr>
						      <th scope="col">image</th>
						      <th scope="col">Tên SP</th>
						      <th scope="col">Số lượng</th>
						      <th scope="col">Xóa</th>
						      <th scope="col">Đơn giá</th>
						      <th scope="col">Thành tiên</th>
						    </tr>
						  </thead>
						  <tbody>
						    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    <tr>
				           		<td>
				               		<img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/hinh_sach/'.$row->options->hinh)); ?>" class="img-thumbnail" style="max-width: 150px">
				           		</td>
				           		<td><?php echo e($row->name); ?></td>
				           		<td>
			           			<form class="form-inline" method="post" action="<?php echo e(url('khach-hang/cap-nhat-gio-hang')); ?>">
			           				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			           				<input type="hidden" value="<?php echo e($row->rowId); ?>" name="Th_rowID">
				           			<select name="Th_soluong" class="form-control" style="width: 100px; text-align: center;">
				           			<?php for($i = 1; $i <= 10; $i++): ?>
				           				<?php if($i == ($row->qty*1)): ?>
										    <option value="<?php echo e($i); ?>" selected="selected"><?php echo e($i); ?></option>
										<?php else: ?>
										    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
										<?php endif; ?>
									<?php endfor; ?>
				           			</select>
				           			<input type="submit" name="Th_submit" value="Cập nhật" class="btn btn-primary btn-sm">
			           			</form>	

				           		</td>
				           		<td><a href="<?php echo e(url('khach-hang/xoa-mat-hang/'.$row->rowId)); ?>">Xóa</a></td>
				           		<td><?php echo e(number_format($row->price)); ?> đ</td>
				           		<td><?php echo e(number_format($row->qty*$row->price)); ?> đ</td>
				       		</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </tbody>
						  <tfoot>
						   		<tr class="bg-info">
						   			<td>Tổng tiền</td>
						   			<td colspan="4">&nbsp;</td>
						   			
						   			<td><?php echo Cart::total(); ?></td>
						   		</tr>
						   		
						   	</tfoot>
						</table>
						<a href="<?php echo e(url('khach-hang/tien-hanh-dat-hang')); ?>" class="btn bg-warning"> Tiến hành đặt hàng</a>
					<?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/khach_hang/thong_tin_gio_hang.blade.php ENDPATH**/ ?>