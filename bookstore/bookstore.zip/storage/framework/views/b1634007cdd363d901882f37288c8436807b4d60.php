
<?php $__env->startSection('title', 'Chi-tiet'); ?>
<?php $__env->startSection('content'); ?>
<section class="recomended-sec">
    <div class="container">
        <div class="title">
            <h2><?php echo e($loaisach->ten_loai_sach); ?></h2>
            <hr>
        </div>
        <div class="row">
        <?php $__currentLoopData = $sachtheoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img class="rounded mx-auto d-block" src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/hinh_sach/<?php echo e($sach->hinh); ?>" alt="img" width="150px" height="200px" >
                    <h3><?php echo e($sach->ten_sach); ?></h3>
                    <h6><span class="price"><?php echo e($sach->don_gia); ?></span> / <a href="#">Buy Now</a></h6>
                    <div class="hover">
                        <a href="<?php echo e(url('sach')); ?>/<?php echo e($sach->ten_url); ?>-<?php echo e($sach->id); ?>">
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
                <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/san_pham/sach_theo_loai.blade.php ENDPATH**/ ?>