
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content1'); ?>
<section class="recomended-sec">
    <div class="container">
        <div class="title">
            <h2>highly recommendes books</h2>
            <hr>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/images/img1.jpg" alt="img">
                    <h3>how to be a bwase</h3>
                    <h6><span class="price">$49</span> / <a href="#">Buy Now</a></h6>
                    <div class="hover">
                        <a href="product-single.html">
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/images/img2.jpg" alt="img">
                    <h3>How to write a book...</h3>
                    <h6><span class="price">$19</span> / <a href="#">Buy Now</a></h6>
                    <span class="sale">Sale !</span>
                    <div class="hover">
                        <a href="product-single.html">
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/images/img3.jpg" alt="img">
                    <h3>7-day self publish...</h3>
                    <h6><span class="price">$49</span> / <a href="#">Buy Now</a></h6>
                    <div class="hover">
                        <a href="product-single.html">
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/images/img4.jpg" alt="img">
                    <h3>wendy doniger</h3>
                    <h6><span class="price">$49</span> / <a href="#">Buy Now</a></h6>
                    <div class="hover">
                        <a href="product-single.html">
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content2'); ?>
<section class="recomended-sec">
    <div class="container">
        <div class="title">
            <h2>Danh Mục Tổng Hợp</h2>
            <hr>
        </div>
        <div class="row">
            <?php $__currentLoopData = $DsSach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/hinh_sach/<?php echo e($sach->hinh); ?>" alt="img">
                    <h3><a href="#"><?php echo e($sach->ten_sach); ?></a></h3>
                    <h6><span class="price"><?php echo e($sach->don_gia); ?></span> / <a href="#">Buy Now</a></h6>
                    <div class="hover">
                        <a href="product-single.html">
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
                <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <?php echo e($DsSach->links()); ?>

                    </ul>
                </nav>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/san_pham_bookstore/index.blade.php ENDPATH**/ ?>