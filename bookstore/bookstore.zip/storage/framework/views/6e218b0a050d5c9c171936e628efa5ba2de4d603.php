
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>
<?php if(count($errors)>0): ?>
    <div class="alert alert-alert">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php endif; ?>
    <?php if(session('alert')): ?>
    
    <div class="alert alert-success">
      <?php echo e(session('alert')); ?>

    </div>
    <?php endif; ?>
<div class="breadcrumb">
    <div class="container">
        <a class="breadcrumb-item" href="<?php echo e(url('/sach')); ?>">Home</a>
        <span class="breadcrumb-item active">Login</span>
    </div>
</div>
<section class="static about-sec">
    <div class="container">
        <h1>Đăng Nhập</h1>
        <div class="form">
            <form method="POST" action="<?php echo e(url('khach-hang/dang-nhap')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <div class="row">
                    <div class="col-md-5">
                        <input type="email" name="email" placeholder="Enter Email" required>
                        <span class="required-star">*</span>
                    </div>
                    <div class="col-md-5">
                        <input type="password" name="password" placeholder="Enter PassWord" required>
                        <span class="required-star">*</span>
                    </div>
                    <div class="col-lg-8 col-md-12">
                        <button class="btn black">Login</button>
                        <h5>not Registd? <a href="<?php echo e(url('khach-hang/dang-ky')); ?>">Đăng ký</a></h5>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/khach_hang/login.blade.php ENDPATH**/ ?>