
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <?php if(count($errors)>0): ?>
    <div class="alert alert-success">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php endif; ?>
    <?php if(session('alert')): ?>
    
    <div class="alert alert-danger">
      <?php echo e(session('alert')); ?>

    </div>
    <?php endif; ?>
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
      <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Danh Sách Sản Phẩm</h4>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>
                      STT
                    </th>
                    <th>
                      Tên Sách
                    </th>
                    <th>
                      Hình
                    </th>
                    <th>
                      Tác Giả
                    </th>
                    <th>
                      Nhà Xuất Bản
                    </th>
                    <th>
                      Đơn Giá
                    </th>
                    <th>
                      Trạng Thái
                    </th>
                    <th>
                      Sửa|Xoá
                    </th>
                  </tr>
                </thead>
                <tbody>

                  <?php $__currentLoopData = $dssach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <?php echo e($sach->id); ?>

                    </td>
                    <td>
                      <?php echo e($sach->ten_sach); ?>

                    </td>
                    <td>
                      <img src="<?php echo e(URL::asset('storage/css_js_image_bookstore/')); ?>/hinh_sach/<?php echo e($sach->hinh); ?>" alt="img" style="width: 200px;height:150px">
                    </td>
                    <td>
                      <?php echo e($sach->id_tac_gia); ?>

                    </td>
                    <td>
                      <?php echo e($sach->id_nha_xuat_ban); ?>

                    </td>
                    <td>
                      <?php echo e($sach->don_gia); ?>

                    </td>
                    <td>
                      <?php echo e($sach->trang_thai); ?>

                    </td>
                    <td>
                    <a href="<?php echo e(url('admin/cap-nhat-sach')); ?>/<?php echo e($sach->id); ?>"> <img src="<?php echo e(URL::asset('storage/icon/create-black-18dp.svg')); ?>" /></a>|
                    <a href="<?php echo e(url('admin/destroy')); ?>/<?php echo e($sach->id); ?>"> <img src="<?php echo e(URL::asset('storage/icon/delete-black-18dp.svg')); ?>" /></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-md-12">
            <nav aria-label="Page navigation example">
              <ul class="pagination justify-content-center">
                <?php echo e($dssach->links()); ?>

              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/admin/kho-sach.blade.php ENDPATH**/ ?>