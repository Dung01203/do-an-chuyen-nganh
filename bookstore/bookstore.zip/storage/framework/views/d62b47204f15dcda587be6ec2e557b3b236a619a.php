
<?php $__env->startSection('title', 'Bookstore'); ?>
<?php $__env->startSection('content'); ?>

<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
    <div class="col-md-12">
    <?php if(count($errors)>0): ?>
    <div class="alert alert-success">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php endif; ?>
    <?php if(session('alert')): ?>
    
    <div class="alert alert-danger">
      <?php echo e(session('alert')); ?>

    </div>
    <?php endif; ?>
  </div>

      <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">Cập nhập Tác Giả </h4>
            <form class="forms-sample" method="POST" action="<?php echo e(URL('admin/cap-nhat-tg')); ?>/<?php echo e($tacgia->id); ?>" enctype="multipart/form-data">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
              <?php echo e(method_field('PUT')); ?>

              <div class="form-group">
                <label>Tên Tác Giả :</label>
                <input type="text" class="form-control" name="ten_tac_gia" id="ten_tac_gia" value="<?php echo e($tacgia->ten_tac_gia); ?>" placeholder="Nhập tên Tác Giả ">
              </div>
              <div class="form-group">
                <label>Ngày sinh :</label>
                <input type="date" name="ngay_sinh" id="ngay_sinh"value="<?php echo e($tacgia->ngay_sinh); ?>>
              </div>

              <div class="form-group">
                <label>Giới Thiệu:</label>
                <textarea name="gioi_thieu" class="ckeditor" value="{<?php echo $tacgia->gioi_thieu; ?>}"></textarea>
              </div>
              
              <button type="submit" class="btn btn-primary mr-2">Cập nhập Tác Giả</button>

            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(URL::asset('storage/ckeditor/ckeditor.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout_admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/admin/cap-nhap-tg.blade.php ENDPATH**/ ?>