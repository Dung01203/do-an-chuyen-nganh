
<?php $__env->startSection('title', 'Chi-tiet'); ?>
<?php $__env->startSection('content'); ?>
<section class="recomended-sec">
    <div class="container">

        <div class="title">
            <h2></h2>
            <hr>
        </div>
        <div class="row">
          
            <div class="col-lg-3 col-md-6">
                <div class="item">
                    <img src="#" alt="img">
                    <h3><a href="#" id="ten_sach"></a></h3>
                    <h6><span class="price"></span> / <a href="#">Buy Now</a></h6>
                    <div class="hover">
                        <a href="" >
                            <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                        </a>
                    </div>
                </div>
                <br>
            </div>
            
        </div>
        <div class="row">
            <div class="col-md-12">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                    
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bookstore\resources\views/san_pham/danh_sach.blade.php ENDPATH**/ ?>